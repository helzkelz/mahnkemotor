// PHASE 1 — THE OUTER GATES (HomePage)
// This page is pure intrigue. No nav, no explanation.
// Interaction (click/tap/key) triggers shatter animation and advances to /portal.

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/router';
import { motion, AnimatePresence } from 'framer-motion';

const mysteryText = "You weren't supposed to find this place.";

export default function HomePage() {
  const router = useRouter();
  const [typed, setTyped] = useState('');
  const [shatter, setShatter] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Typewriter effect
  useEffect(() => {
    if (typed.length < mysteryText.length && !shatter) {
      const timeout = setTimeout(() => {
        setTyped(mysteryText.slice(0, typed.length + 1));
      }, 45);
      return () => clearTimeout(timeout);
    }
  }, [typed, shatter]);

  // Handle user interaction to shatter and go to portal
  const handleAdvance = () => {
    if (shatter) return;
    setShatter(true);
    // Play shatter sound
    if (audioRef.current) audioRef.current.play();
    setTimeout(() => router.push('/portal'), 1200); // Delay for animation
  };

  // Allow any click, tap, or key to trigger
  useEffect(() => {
    const onAny = () => handleAdvance();
    window.addEventListener('click', onAny);
    window.addEventListener('keydown', onAny);
    window.addEventListener('touchstart', onAny);
    return () => {
      window.removeEventListener('click', onAny);
      window.removeEventListener('keydown', onAny);
      window.removeEventListener('touchstart', onAny);
    };
  }, [shatter]);

  return (
    <div className="homepage-container" style={{
      minHeight: '100vh',
      background: 'black',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer'
    }}>
      <AnimatePresence>
        {!shatter && (
          <motion.h1
            key="mystery"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.4, rotate: 15, filter: 'blur(10px)' }}
            transition={{ duration: 0.8 }}
            style={{
              color: 'white',
              fontSize: '2.3rem',
              fontFamily: 'monospace',
              letterSpacing: '0.03em',
              position: 'relative'
            }}
          >
            {typed}
            <span className="typed-cursor" style={{
              display: 'inline-block',
              width: '1ch',
              animation: 'blink 1s step-end infinite'
            }}>|</span>
          </motion.h1>
        )}
        {shatter && (
          <motion.div
            key="shatter"
            initial={{ opacity: 1 }}
            animate={{ opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.1 }}
            style={{ width: 0, height: 0 }}
          />
        )}
      </AnimatePresence>
      <audio ref={audioRef} src="/sounds/glass-shatter.mp3" preload="auto" />
      <style jsx>{`
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
      `}</style>
    </div>
  );
}