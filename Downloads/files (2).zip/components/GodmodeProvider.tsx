import React, { createContext, useContext } from 'react';
import { useStore } from '../store';
import { personaThemes } from '../themes/personaThemes';

const GodmodeContext = createContext({});

export function GodmodeProvider({ children }) {
  const { persona, session, consent, featureUnlocks } = useStore();
  const theme = personaThemes[persona] || personaThemes['default'];

  return (
    <GodmodeContext.Provider value={{
      persona,
      session,
      consent,
      featureUnlocks,
      theme,
    }}>
      <div style={{
        background: theme.bg,
        color: theme.text,
        fontFamily: theme.fontFamily,
        minHeight: '100vh'
      }}>
        {children}
      </div>
    </GodmodeContext.Provider>
  );
}

export const useGodmode = () => useContext(GodmodeContext);