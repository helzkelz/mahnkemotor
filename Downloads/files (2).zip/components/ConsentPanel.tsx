import { useState } from 'react';
import { logConsent } from '../utils/agentClient';
import { useGodmode } from './GodmodeProvider';

export default function ConsentPanel() {
  const { consent } = useGodmode();
  const [loading, setLoading] = useState(false);

  const handleConsent = async (type, status) => {
    setLoading(true);
    await logConsent(type, status);
    setLoading(false);
    // Optionally trigger SENTINEL@1
  };

  return (
    <div>
      <h3>Consent Dashboard</h3>
      <p>Status: {consent ? '✅ Given' : '❌ Not Given'}</p>
      <button disabled={loading} onClick={() => handleConsent('main', !consent)}>
        {consent ? 'Revoke Consent' : 'Give Consent'}
      </button>
    </div>
  );
}