// Abstracts calls to backend agent/mission APIs
export async function triggerMission(missionType: string, payload: any) {
  const res = await fetch('/api/trigger-mission', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ missionType, payload }),
  });
  if (!res.ok) throw new Error('Mission trigger failed');
  return await res.json();
}

export async function logConsent(consentType: string, status: boolean) {
  return fetch('/api/consent', {
    method: 'POST',
    body: JSON.stringify({ consentType, status }),
    headers: { 'Content-Type': 'application/json' },
  });
}

export async function unlockFeature(feature: string) {
  return fetch('/api/profile', {
    method: 'POST',
    body: JSON.stringify({ unlock: feature }),
    headers: { 'Content-Type': 'application/json' },
  });
}