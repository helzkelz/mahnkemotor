import { Link, useLocation } from "wouter";
import { Box, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Header() {
  const [location] = useLocation();

  return (
    <header className="bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link href="/">
            <div className="flex items-center space-x-3 cursor-pointer">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                <Box className="text-white w-4 h-4" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-slate-900">HelenKella Suite</h1>
                <p className="text-xs text-slate-500">Your Tools. Your Rules. Your Data.</p>
              </div>
            </div>
          </Link>
          <div className="flex items-center space-x-4">
            <div className="hidden sm:flex items-center space-x-2 text-sm">
              <span className="w-2 h-2 bg-emerald-500 rounded-full"></span>
              <span className="text-slate-600">Licensed & Owned</span>
            </div>
            <Link href="/settings">
              <Button 
                variant="outline" 
                size="sm"
                className="bg-slate-100 hover:bg-slate-200 border-slate-200"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
