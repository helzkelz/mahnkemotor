import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Palette, Grid3X3, List, LayoutGrid, Rows3 } from "lucide-react";

export type ViewMode = "grid" | "list" | "carousel" | "accordion" | "compact";
export type ColorTheme = "default" | "dark" | "warm" | "cool" | "neon";

interface ThemeSwitcherProps {
  viewMode: ViewMode;
  colorTheme: ColorTheme;
  onViewModeChange: (mode: ViewMode) => void;
  onColorThemeChange: (theme: ColorTheme) => void;
}

const viewModeIcons = {
  grid: Grid3X3,
  list: List,
  carousel: LayoutGrid,
  accordion: Rows3,
  compact: Grid3X3
};

const viewModeLabels = {
  grid: "Grid View",
  list: "List View", 
  carousel: "Carousel",
  accordion: "Accordion",
  compact: "Compact"
};

const colorThemes = {
  default: { name: "Default", class: "", preview: "bg-slate-100" },
  dark: { name: "Dark Mode", class: "theme-dark", preview: "bg-slate-800" },
  warm: { name: "Warm Tones", class: "theme-warm", preview: "bg-orange-100" },
  cool: { name: "Cool Blues", class: "theme-cool", preview: "bg-blue-100" },
  neon: { name: "Neon Vibes", class: "theme-neon", preview: "bg-purple-100" }
};

export function ThemeSwitcher({ viewMode, colorTheme, onViewModeChange, onColorThemeChange }: ThemeSwitcherProps) {
  const ViewIcon = viewModeIcons[viewMode];

  return (
    <div className="flex items-center space-x-2">
      {/* View Mode Switcher */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="flex items-center space-x-2">
            <ViewIcon className="w-4 h-4" />
            <span>{viewModeLabels[viewMode]}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {Object.entries(viewModeLabels).map(([mode, label]) => {
            const Icon = viewModeIcons[mode as ViewMode];
            return (
              <DropdownMenuItem 
                key={mode}
                onClick={() => onViewModeChange(mode as ViewMode)}
                className="flex items-center space-x-2"
              >
                <Icon className="w-4 h-4" />
                <span>{label}</span>
                {mode === viewMode && <Badge variant="secondary" className="ml-auto">Active</Badge>}
              </DropdownMenuItem>
            );
          })}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Color Theme Switcher */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="flex items-center space-x-2">
            <Palette className="w-4 h-4" />
            <span>{colorThemes[colorTheme].name}</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {Object.entries(colorThemes).map(([theme, config]) => (
            <DropdownMenuItem 
              key={theme}
              onClick={() => onColorThemeChange(theme as ColorTheme)}
              className="flex items-center space-x-2"
            >
              <div className={`w-4 h-4 rounded-full ${config.preview}`}></div>
              <span>{config.name}</span>
              {theme === colorTheme && <Badge variant="secondary" className="ml-auto">Active</Badge>}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}