import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PaymentOptions } from "@/components/payment-options";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Check, Star, Zap } from "lucide-react";

interface UpgradeSection {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  items: {
    title: string;
    price: string;
    features: string[];
    buttonText: string;
    isPopular?: boolean;
    category?: string;
    shortDesc?: string;
  }[];
}

interface UpgradeAccordionProps {
  sections: UpgradeSection[];
}

export function UpgradeAccordion({ sections }: UpgradeAccordionProps) {
  return (
    <Accordion type="multiple" className="w-full space-y-4">
      {sections.map((section) => (
        <AccordionItem 
          key={section.id} 
          value={section.id}
          className="border border-slate-200 rounded-lg px-6 bg-white shadow-sm"
        >
          <AccordionTrigger className="hover:no-underline py-6">
            <div className="flex items-center space-x-4 text-left">
              <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                {section.icon}
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-slate-900">{section.title}</h3>
                <p className="text-sm text-slate-600 mt-1">{section.description}</p>
              </div>
              <Badge variant="secondary" className="ml-auto">
                {section.items.length} items
              </Badge>
            </div>
          </AccordionTrigger>
          
          <AccordionContent className="pb-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
              {section.items.map((item, index) => (
                <Card key={index} className={`transition-all duration-200 hover:shadow-md ${
                  item.isPopular ? 'border-emerald-200 bg-emerald-50' : 'border-slate-200'
                }`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-slate-900">{item.title}</h4>
                          {item.isPopular && (
                            <Star className="w-4 h-4 text-emerald-600 fill-current" />
                          )}
                        </div>
                        {item.category && (
                          <Badge variant="outline" className="text-xs">
                            {item.category}
                          </Badge>
                        )}
                      </div>
                      <span className="text-lg font-bold text-slate-900">{item.price}</span>
                    </div>

                    {item.shortDesc ? (
                      <p className="text-sm text-slate-600 mb-3">{item.shortDesc}</p>
                    ) : (
                      <ul className="text-sm text-slate-600 space-y-1 mb-3">
                        {item.features.slice(0, 3).map((feature, idx) => (
                          <li key={idx} className="flex items-start space-x-2">
                            <Check className="w-3 h-3 text-emerald-600 mt-0.5 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                        {item.features.length > 3 && (
                          <li className="text-xs text-slate-400 pl-5">
                            + {item.features.length - 3} more features
                          </li>
                        )}
                      </ul>
                    )}

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          size="sm" 
                          className="w-full" 
                          variant={item.isPopular ? "default" : "outline"}
                        >
                          {item.buttonText}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <PaymentOptions 
                          itemName={item.title} 
                          price={item.price} 
                        />
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}