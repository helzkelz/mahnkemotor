import { Link } from "wouter";
import { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface AppCardProps {
  name: string;
  description: string;
  icon: LucideIcon;
  color: "emerald" | "blue" | "purple";
  href: string;
  recentActivity?: Array<{
    label: string;
    value?: string;
    color?: string;
  }>;
  children?: React.ReactNode;
}

export function AppCard({ 
  name, 
  description, 
  icon: Icon, 
  color, 
  href, 
  recentActivity,
  children 
}: AppCardProps) {
  const colorClasses = {
    emerald: {
      icon: "bg-emerald-100 text-emerald-600",
      button: "bg-emerald-600 hover:bg-emerald-700"
    },
    blue: {
      icon: "bg-blue-100 text-blue-600",
      button: "bg-blue-600 hover:bg-blue-700"
    },
    purple: {
      icon: "bg-purple-100 text-purple-600",
      button: "bg-purple-600 hover:bg-purple-700"
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
      <div className="p-6 border-b border-slate-100">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className={`w-10 h-10 ${colorClasses[color].icon} rounded-xl flex items-center justify-center`}>
              <Icon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900">{name}</h3>
              <p className="text-sm text-slate-500">{description}</p>
            </div>
          </div>
          <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-xs font-medium rounded-full">
            Owned
          </span>
        </div>
        <Link href={href}>
          <Button className={`w-full text-white ${colorClasses[color].button}`}>
            Open {name}
          </Button>
        </Link>
      </div>
      {recentActivity && (
        <div className="p-6 bg-slate-50">
          <h4 className="font-medium text-slate-700 mb-3">Recent Activity</h4>
          <div className="space-y-2">
            {recentActivity.map((item, index) => (
              <div key={index} className="flex justify-between items-center text-sm">
                <span className="text-slate-600">{item.label}</span>
                {item.value && (
                  <span className={`font-medium ${item.color || 'text-slate-700'}`}>
                    {item.value}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
      {children && (
        <div className="p-6 bg-slate-50">
          {children}
        </div>
      )}
    </div>
  );
}
