import { useQuery } from "@tanstack/react-query";

export interface DashboardStats {
  outstandingRevenue: number;
  activeProjects: number;
  weeklyHours: number;
  filesOrganized: number;
  recentInvoices: Array<{
    description: string;
    amount: number;
    type: 'income' | 'expense';
  }>;
  nextTasks: Array<{
    title: string;
    priority: 'low' | 'medium' | 'high';
  }>;
  recentFiles: Array<{
    name: string;
    type: string;
  }>;
}

export function useStats() {
  return useQuery<DashboardStats>({
    queryKey: ['/api/stats'],
    retry: false,
  });
}
