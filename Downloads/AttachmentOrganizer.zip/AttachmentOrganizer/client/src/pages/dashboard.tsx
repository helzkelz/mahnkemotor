import { Header } from "@/components/header";
import { StatCard } from "@/components/stat-card";
import { AppCard } from "@/components/app-card";
import { UpgradeCard } from "@/components/upgrade-card";
import { useStats } from "@/hooks/use-stats";
import { 
  TrendingUp, 
  FolderOpen, 
  Clock, 
  FileText,
  Calculator,
  Calendar,
  Bolt,
  Code,
  FileImage,
  File
} from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { data: stats, isLoading } = useStats();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-slate-200 rounded w-64 mb-2"></div>
            <div className="h-4 bg-slate-200 rounded w-96 mb-8"></div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-24 bg-slate-200 rounded-xl"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Welcome back, Alex</h2>
          <p className="text-slate-600">Your productivity suite is ready. No subscriptions, no data mining, just tools that work for you.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <StatCard
            title="Outstanding Revenue"
            value={stats ? `$${stats.outstandingRevenue.toLocaleString()}` : "$0"}
            icon={TrendingUp}
            color="emerald"
          />
          <StatCard
            title="Active Projects"
            value={stats ? stats.activeProjects.toString() : "0"}
            icon={FolderOpen}
          />
          <StatCard
            title="This Week"
            value={stats ? `${stats.weeklyHours}h` : "0h"}
            icon={Clock}
          />
          <StatCard
            title="Files Organized"
            value={stats ? stats.filesOrganized.toString() : "0"}
            icon={FileText}
          />
        </div>

        {/* Main Apps Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <AppCard
            name="Ledger"
            description="Financial Management"
            icon={Calculator}
            color="emerald"
            href="/ledger"
            recentActivity={stats?.recentInvoices.map(invoice => ({
              label: invoice.description,
              value: invoice.type === 'income' ? `$${invoice.amount}` : `-$${invoice.amount}`,
              color: invoice.type === 'income' ? 'text-emerald-600' : 'text-red-500'
            }))}
          />

          <AppCard
            name="Agenda"
            description="Time & Task Management"
            icon={Calendar}
            color="blue"
            href="/agenda"
          >
            <h4 className="font-medium text-slate-700 mb-3">Next Steps</h4>
            <div className="space-y-3">
              {stats?.nextTasks.map((task, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className={`w-2 h-2 rounded-full ${
                    task.priority === 'high' ? 'bg-red-400' :
                    task.priority === 'medium' ? 'bg-orange-400' : 'bg-emerald-400'
                  }`}></div>
                  <span className="text-sm text-slate-700">{task.title}</span>
                </div>
              )) || (
                <div className="text-sm text-slate-500">No upcoming tasks</div>
              )}
            </div>
          </AppCard>

          <AppCard
            name="Docket"
            description="File & Client Organization"
            icon={FolderOpen}
            color="purple"
            href="/docket"
          >
            <h4 className="font-medium text-slate-700 mb-3">Recent Files</h4>
            <div className="space-y-2">
              {stats?.recentFiles.map((file, index) => (
                <div key={index} className="flex items-center space-x-2 text-sm">
                  {file.type === 'pdf' ? <File className="w-4 h-4 text-red-500" /> :
                   file.type === 'image' ? <FileImage className="w-4 h-4 text-blue-500" /> :
                   <FileText className="w-4 h-4 text-green-500" />}
                  <span className="text-slate-700">{file.name}</span>
                </div>
              )) || (
                <div className="text-sm text-slate-500">No recent files</div>
              )}
            </div>
          </AppCard>
        </div>

        {/* Arsenal Section */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-8">
          <div className="p-6 border-b border-slate-100">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center">
                  <Bolt className="text-orange-600 w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-slate-900">Arsenal</h3>
                  <p className="text-sm text-slate-500">Optional upgrades & power-ups</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-xs text-slate-500">No subscriptions</p>
                <p className="text-xs font-medium text-emerald-600">Own forever</p>
              </div>
            </div>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <UpgradeCard
                title="Ledger Pro Pack"
                price="$49"
                features={[
                  "Advanced tax reporting",
                  "Multi-currency support",
                  "Client retainer tracking"
                ]}
                buttonText="Learn More"
                buttonVariant="secondary"
              />

              <UpgradeCard
                title="OCR Scanner"
                price="$9.99"
                features={[
                  "Scan receipts instantly",
                  "Auto-extract data",
                  "On-device processing"
                ]}
                buttonText="Add to Ledger"
                buttonVariant="default"
                type="highlighted"
              />

              <UpgradeCard
                title="Plaid Pass"
                price="$15"
                features={[]}
                description="Bank sync service. This covers ongoing costs—we don't profit from it."
                buttonText="Optional Add-on"
                buttonVariant="outline"
                type="service"
                isRecurring={true}
              />
            </div>
          </div>
        </div>

        {/* Forge Section */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl text-white overflow-hidden">
          <div className="p-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-slate-700 rounded-xl flex items-center justify-center">
                <Code className="text-slate-300 w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">The Forge</h3>
                <p className="text-sm text-slate-300">Customize and script your workflow</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3">Your Scripts</h4>
                <div className="bg-slate-800 rounded-lg p-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">Auto-invoice generator</span>
                    <span className="text-emerald-400">Active</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">Client report builder</span>
                    <span className="text-slate-400">Draft</span>
                  </div>
                  <button className="text-xs text-slate-400 hover:text-slate-300 transition-colors">
                    + Add new script
                  </button>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Community Scripts</h4>
                <div className="bg-slate-800 rounded-lg p-4 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">Tax prep automation</span>
                    <button className="text-emerald-400 hover:text-emerald-300 transition-colors text-xs">Install</button>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-300">Time tracking widget</span>
                    <button className="text-emerald-400 hover:text-emerald-300 transition-colors text-xs">Install</button>
                  </div>
                  <button className="text-xs text-slate-400 hover:text-slate-300 transition-colors">
                    Browse all scripts →
                  </button>
                </div>
              </div>
            </div>
            
            <Button className="mt-4 bg-slate-700 hover:bg-slate-600 text-white">
              <FolderOpen className="w-4 h-4 mr-2" />
              Open Scripts Folder
            </Button>
          </div>
        </div>

        {/* Philosophy Footer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-slate-500 mb-2">Built with respect for your autonomy, privacy, and workflow.</p>
          <p className="text-xs text-slate-400">No data mining • No forced updates • No subscription traps</p>
        </div>
      </div>
    </div>
  );
}
