import { Header } from "@/components/header";
import { UpgradeCard } from "@/components/upgrade-card";
import { UpgradeCarousel } from "@/components/upgrade-carousel";
import { UpgradeAccordion } from "@/components/upgrade-accordion";
import { ThemeSwitcher, ViewMode, ColorTheme } from "@/components/theme-switcher";
import { PaymentOptions } from "@/components/payment-options";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Bolt, Star, Shield, Zap, Workflow, Brain, Cog, Sparkles } from "lucide-react";
import { useState } from "react";

export default function Arsenal() {
  const [viewMode, setViewMode] = useState<ViewMode>("carousel");
  const [colorTheme, setColorTheme] = useState<ColorTheme>("default");

  // Dynamic data structure - no hard barriers
  const upgradeSections = [
    {
      id: "workflows",
      title: "Automated Workflows",
      description: "Pre-built automation sequences that adapt to your work patterns",
      icon: <Workflow className="w-5 h-5 text-blue-600" />,
      items: [
        {
          title: "Executive Dysfunction Support",
          price: "$19",
          features: [
            "Auto-break large tasks into steps",
            "Context-switching helpers", 
            "Energy level task matching",
            "Gentle reminder system"
          ],
          buttonText: "Buy Workflow",
          category: "Accessibility",
          isPopular: true
        },
        {
          title: "Invoice-to-Payment Flow", 
          price: "$15",
          features: [
            "Auto-generate invoices from time logs",
            "Smart payment reminder sequence",
            "Follow-up templates",
            "Late payment escalation"
          ],
          buttonText: "Buy Workflow",
          category: "Finance"
        },
        {
          title: "Client Onboarding Sequence",
          price: "$25", 
          features: [
            "Welcome packet automation",
            "Contract template system",
            "Project setup checklist",
            "Communication preferences setup"
          ],
          buttonText: "Buy Workflow",
          category: "Client Management"
        },
        {
          title: "Project Completion Flow",
          price: "$12",
          features: [
            "Auto-archive completed projects",
            "Generate project reports", 
            "Client satisfaction survey",
            "Case study template creation"
          ],
          buttonText: "Buy Workflow",
          category: "Project Management"
        },
        {
          title: "Quarterly Business Review",
          price: "$18",
          features: [
            "Revenue and expense analysis",
            "Goal achievement tracking",
            "Client retention metrics", 
            "Strategic planning prompts"
          ],
          buttonText: "Buy Workflow",
          category: "Analytics"
        },
        {
          title: "Tax Season Prep",
          price: "$22",
          features: [
            "Expense categorization helper",
            "Receipt organization system",
            "Deduction optimization guide",
            "Tax document generation"
          ],
          buttonText: "Buy Workflow",
          category: "Finance"
        }
      ]
    },
    {
      id: "pro-packs",
      title: "Pro Packs", 
      description: "Major functionality bundles that transform your core apps",
      icon: <Star className="w-5 h-5 text-orange-600" />,
      items: [
        {
          title: "Ledger Pro Pack",
          price: "$49",
          features: [
            "Advanced tax reporting (Schedule C, quarterly estimates)",
            "Multi-currency support with real-time exchange rates", 
            "Client retainer management and tracking",
            "Custom invoice templates and branding",
            "Automated payment reminders"
          ],
          buttonText: "Upgrade Ledger",
          isPopular: true,
          category: "Finance Suite"
        },
        {
          title: "Agenda Pro Pack",
          price: "$39",
          features: [
            "Gantt charts and visual project timelines",
            "Advanced analytics and time reporting",
            "Goal tracking with milestone management",
            "Team collaboration features", 
            "Calendar integrations (Google, Outlook)"
          ],
          buttonText: "Upgrade Agenda",
          category: "Time Management"
        },
        {
          title: "Docket Pro Pack",
          price: "$29",
          features: [
            "Advanced file organization with tags",
            "Client portal with secure file sharing",
            "Version control and file history",
            "Automated backup to cloud storage",
            "Advanced search with OCR"
          ],
          buttonText: "Upgrade Docket",
          category: "File Management"
        }
      ]
    },
    {
      id: "power-ups",
      title: "Power-Ups",
      description: "Focused micro-tools that solve specific pain points", 
      icon: <Zap className="w-5 h-5 text-purple-600" />,
      items: [
        {
          title: "OCR Scanner",
          price: "$9.99",
          features: ["Scan receipts instantly", "Auto-extract data", "On-device processing"],
          buttonText: "Add to Ledger",
          category: "Productivity"
        },
        {
          title: "Smart Time Tracker",
          price: "$7.99", 
          features: ["AI-powered activity detection", "Auto-categorize work time", "Distraction warnings"],
          buttonText: "Add to Agenda",
          category: "Time Tracking"
        },
        {
          title: "Client Portal",
          price: "$29.99",
          features: ["Secure client webpage", "Project file access", "Invoice viewing"],
          buttonText: "Add to Docket",
          category: "Client Tools"
        },
        {
          title: "Focus Mode",
          price: "$4.99",
          features: ["Website blocking", "Ambient sounds", "Break reminders"],
          buttonText: "Add to Suite",
          category: "Focus"
        },
        {
          title: "Voice Notes",
          price: "$12.99",
          features: ["Audio transcription", "Quick voice memos", "Meeting recordings"],
          buttonText: "Add to Docket",
          category: "Productivity"
        },
        {
          title: "Expense Tracker",
          price: "$8.99",
          features: ["Photo receipt capture", "Mileage tracking", "Category suggestions"],
          buttonText: "Add to Ledger",
          category: "Finance"
        }
      ]
    },
    {
      id: "forge",
      title: "Personal Forge",
      description: "Build custom tools and workflows with our no-code editor",
      icon: <Brain className="w-5 h-5 text-purple-600" />,
      items: [
        {
          title: "Script Editor",
          price: "Coming Soon",
          features: ["Visual workflow builder", "JavaScript automation scripting", "API integration helpers", "Custom UI components"],
          buttonText: "Join Waitlist",
          category: "Development"
        },
        {
          title: "Community Marketplace",
          price: "Coming Soon",
          features: ["Share your creations", "Download community scripts", "Rate and review tools", "Monetize your work"],
          buttonText: "Join Waitlist",
          category: "Community"
        }
      ]
    }
  ];

  // Completely flexible rendering - no barriers between layouts
  const renderContent = () => {
    // Dynamic content rendering based on view mode - no hard barriers
    if (viewMode === "carousel") {
      return (
        <div className="space-y-8">
          {upgradeSections.map((section) => (
            <UpgradeCarousel
              key={section.id}
              items={section.items}
              title={section.title}
              subtitle={section.description}
            />
          ))}
        </div>
      );
    }
    
    if (viewMode === "accordion") {
      return <UpgradeAccordion sections={upgradeSections} />;
    }
    
    if (viewMode === "list") {
      return (
        <div className="space-y-6">
          {upgradeSections.map((section) => (
            <div key={section.id} className="space-y-4">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-slate-100 rounded-lg flex items-center justify-center">
                  {section.icon}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900">{section.title}</h2>
                  <p className="text-sm text-slate-600">{section.description}</p>
                </div>
              </div>
              <div className="space-y-3">
                {section.items.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-lg hover:shadow-md transition-shadow">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3">
                        <h3 className="font-medium text-slate-900">{item.title}</h3>
                        <span className="text-lg font-bold text-slate-900">{item.price}</span>
                        {item.category && (
                          <Badge variant="outline" className="text-xs">{item.category}</Badge>
                        )}
                        {item.isPopular && (
                          <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">Popular</Badge>
                        )}
                      </div>
                      <p className="text-sm text-slate-600 mt-1">
                        {item.features.slice(0, 2).join(' • ')}
                        {item.features.length > 2 && ` • +${item.features.length - 2} more`}
                      </p>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant={item.isPopular ? "default" : "outline"}>
                          {item.buttonText}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-md">
                        <PaymentOptions itemName={item.title} price={item.price} />
                      </DialogContent>
                    </Dialog>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      );
    }
    
    if (viewMode === "compact") {
      return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {upgradeSections.flatMap(section => section.items).map((item, index) => (
            <Card key={index} className="p-3 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-medium text-sm text-slate-900 line-clamp-1">{item.title}</h3>
                <span className="text-sm font-bold text-slate-900">{item.price}</span>
              </div>
              <p className="text-xs text-slate-600 mb-3 line-clamp-2">
                {item.features[0]}
              </p>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="sm" className="w-full text-xs" variant="outline">
                    {item.buttonText}
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <PaymentOptions itemName={item.title} price={item.price} />
                </DialogContent>
              </Dialog>
            </Card>
          ))}
        </div>
      );
    }
    
    // Default grid/tab view - flexible and extensible
    return (
      <Tabs defaultValue="workflows" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          {upgradeSections.map((section) => (
            <TabsTrigger key={section.id} value={section.id} className="flex items-center space-x-2">
              {section.icon}
              <span className="hidden sm:inline">{section.title}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {upgradeSections.map((section) => (
          <TabsContent key={section.id} value={section.id} className="mt-8">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">{section.title}</h2>
              <p className="text-slate-600">{section.description}</p>
            </div>
            
            {section.id === "forge" ? (
              <div className="space-y-6">
                <Badge variant="secondary" className="mb-4">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Coming Soon
                </Badge>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {section.items.map((item, index) => (
                    <Card key={index} className="border-purple-200 bg-purple-50">
                      <CardHeader>
                        <CardTitle className="text-lg">{item.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="text-sm text-slate-600 space-y-2">
                          {item.features.map((feature, idx) => (
                            <li key={idx}>• {feature}</li>
                          ))}
                        </ul>
                        <Button className="mt-4 w-full" variant="outline" disabled>
                          {item.buttonText}
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <div className="text-center mt-8">
                  <h3 className="text-lg font-semibold text-slate-900 mb-2">Your Tools, Your Rules</h3>
                  <p className="text-slate-600 max-w-2xl mx-auto">
                    The Forge will let you create exactly the tools you need. Build custom workflows, 
                    automate repetitive tasks, and share your creations with the community. 
                    Because the best productivity system is the one you build yourself.
                  </p>
                </div>
              </div>
            ) : (
              <div className={`grid gap-6 ${
                section.id === "power-ups" 
                  ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-4" 
                  : "grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
              }`}>
                {section.items.map((item, index) => (
                  <UpgradeCard
                    key={index}
                    title={item.title}
                    price={item.price}
                    features={item.features}
                    buttonText={item.buttonText}
                    buttonVariant="default"
                    type={item.isPopular ? "highlighted" : "normal"}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    );
  };

  return (
    <div className={`min-h-screen bg-slate-50 ${colorTheme !== 'default' ? `theme-${colorTheme}` : ''}`}>
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dynamic Header - No Hard Constraints */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
              <Bolt className="text-orange-600 w-6 h-6" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Arsenal & Forge</h1>
              <p className="text-slate-600">Modular upgrades, automated workflows & personal forge</p>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeSwitcher
              viewMode={viewMode}
              colorTheme={colorTheme}
              onViewModeChange={setViewMode}
              onColorThemeChange={setColorTheme}
            />
            <div className="text-right">
              <p className="text-sm text-slate-500">No subscriptions</p>
              <p className="text-sm font-medium text-emerald-600">Own forever</p>
            </div>
          </div>
        </div>

        {/* Philosophy Section - Adaptive */}
        <Card className="mb-8 bg-gradient-to-r from-emerald-50 to-blue-50 border-emerald-200">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                <Shield className="text-emerald-600 w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Arsenal & Forge Philosophy</h3>
                <p className="text-slate-700 mb-4">
                  Choose exactly the tools you need. Build custom workflows. Own them forever. 
                  No subscription traps, no forced updates, no vendor lock-in.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span className="text-slate-600">Modular by design</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span className="text-slate-600">User-scriptable</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span className="text-slate-600">One-time purchases</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span className="text-slate-600">Honest pricing</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Dynamic Content - No Barriers */}
        {renderContent()}

        {/* Honest Services Section - Transparent */}
        <div className="mt-12 mb-8">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Honest Services</h2>
          <p className="text-slate-600 mb-6">
            Some features require ongoing costs. We're transparent about these and don't profit from them.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <UpgradeCard
              title="Bank Sync Service"
              price="$15"
              features={[]}
              description="Secure bank connection via Plaid. This covers their API costs—we don't markup third-party services. Your apps work perfectly without it."
              buttonText="Optional Add-on"
              buttonVariant="outline"
              type="service"
              isRecurring={true}
            />

            <UpgradeCard
              title="Cloud Storage"
              price="$8"
              features={[]}
              description="Encrypted file storage via AWS. Covers actual hosting costs with zero markup. Your data remains private and fully encrypted."
              buttonText="Enable Storage"
              buttonVariant="outline"
              type="service"
              isRecurring={true}
            />
          </div>
        </div>

        {/* Philosophy Footer - No Limits */}
        <div className="text-center pt-8 border-t border-slate-200">
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Keys, Not Cages</h3>
          <p className="text-slate-600 max-w-2xl mx-auto">
            We build tools that empower you, not exploit you. Every purchase is an investment in your productivity, 
            not a rental agreement. Your tools should work for you, not against you.
          </p>
        </div>
      </div>
    </div>
  );
}