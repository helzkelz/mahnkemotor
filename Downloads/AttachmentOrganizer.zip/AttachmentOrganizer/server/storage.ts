import { 
  users, 
  projects, 
  timeEntries, 
  invoices, 
  expenses, 
  tasks, 
  files, 
  userScripts,
  type User, 
  type InsertUser,
  type Project,
  type InsertProject,
  type TimeEntry,
  type InsertTimeEntry,
  type Invoice,
  type InsertInvoice,
  type Expense,
  type InsertExpense,
  type Task,
  type InsertTask,
  type File,
  type InsertFile,
  type UserScript,
  type InsertUserScript
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Project operations
  getProjects(userId: number): Promise<Project[]>;
  getProject(id: number, userId: number): Promise<Project | undefined>;
  createProject(project: InsertProject & { userId: number }): Promise<Project>;
  updateProject(id: number, userId: number, project: Partial<InsertProject>): Promise<Project | undefined>;
  deleteProject(id: number, userId: number): Promise<boolean>;

  // Time entry operations
  getTimeEntries(userId: number, projectId?: number): Promise<TimeEntry[]>;
  createTimeEntry(timeEntry: InsertTimeEntry & { userId: number }): Promise<TimeEntry>;

  // Invoice operations
  getInvoices(userId: number): Promise<Invoice[]>;
  createInvoice(invoice: InsertInvoice & { userId: number }): Promise<Invoice>;
  updateInvoiceStatus(id: number, userId: number, status: string): Promise<Invoice | undefined>;

  // Expense operations
  getExpenses(userId: number): Promise<Expense[]>;
  createExpense(expense: InsertExpense & { userId: number }): Promise<Expense>;

  // Task operations
  getTasks(userId: number, projectId?: number): Promise<Task[]>;
  createTask(task: InsertTask & { userId: number }): Promise<Task>;
  updateTaskStatus(id: number, userId: number, status: string): Promise<Task | undefined>;

  // File operations
  getFiles(userId: number, projectId?: number): Promise<File[]>;
  createFile(file: InsertFile & { userId: number }): Promise<File>;

  // Script operations
  getUserScripts(userId: number): Promise<UserScript[]>;
  createUserScript(script: InsertUserScript & { userId: number }): Promise<UserScript>;
  updateUserScript(id: number, userId: number, script: Partial<InsertUserScript>): Promise<UserScript | undefined>;

  // Dashboard stats
  getDashboardStats(userId: number): Promise<{
    outstandingRevenue: number;
    activeProjects: number;
    weeklyHours: number;
    filesOrganized: number;
    recentInvoices: Array<{ description: string; amount: number; type: 'income' | 'expense' }>;
    nextTasks: Array<{ title: string; priority: 'low' | 'medium' | 'high' }>;
    recentFiles: Array<{ name: string; type: string }>;
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private projects: Map<number, Project>;
  private timeEntries: Map<number, TimeEntry>;
  private invoices: Map<number, Invoice>;
  private expenses: Map<number, Expense>;
  private tasks: Map<number, Task>;
  private files: Map<number, File>;
  private userScripts: Map<number, UserScript>;
  private currentId: number;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
    this.timeEntries = new Map();
    this.invoices = new Map();
    this.expenses = new Map();
    this.tasks = new Map();
    this.files = new Map();
    this.userScripts = new Map();
    this.currentId = 1;

    // Initialize with demo user
    this.initializeWithDemoData();
  }

  private initializeWithDemoData() {
    // Create demo user
    const demoUser: User = {
      id: 1,
      username: "alex",
      email: "alex@example.com",
      firstName: "Alex",
      lastName: "Johnson",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(1, demoUser);

    // Create demo projects
    const project1: Project = {
      id: 2,
      userId: 1,
      name: "Acme Corp Website",
      description: "Complete website redesign for Acme Corporation",
      status: "active",
      clientName: "Acme Corp",
      hourlyRate: "125.00",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(2, project1);

    // Create demo invoices
    const invoice1: Invoice = {
      id: 3,
      userId: 1,
      projectId: 2,
      invoiceNumber: "#1024",
      clientName: "Acme Corp",
      amount: "2500.00",
      status: "sent",
      dueDate: new Date('2024-03-15'),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.invoices.set(3, invoice1);

    // Create demo tasks
    const task1: Task = {
      id: 4,
      userId: 1,
      projectId: 2,
      title: "Review client wireframes",
      description: "Go through the wireframes provided by client",
      status: "pending",
      priority: "high",
      dueDate: new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tasks.set(4, task1);

    this.currentId = 5;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async getProjects(userId: number): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(
      project => project.userId === userId
    );
  }

  async getProject(id: number, userId: number): Promise<Project | undefined> {
    const project = this.projects.get(id);
    return project?.userId === userId ? project : undefined;
  }

  async createProject(projectData: InsertProject & { userId: number }): Promise<Project> {
    const id = this.currentId++;
    const project: Project = {
      ...projectData,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: number, userId: number, projectData: Partial<InsertProject>): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project || project.userId !== userId) return undefined;
    
    const updated = { ...project, ...projectData, updatedAt: new Date() };
    this.projects.set(id, updated);
    return updated;
  }

  async deleteProject(id: number, userId: number): Promise<boolean> {
    const project = this.projects.get(id);
    if (!project || project.userId !== userId) return false;
    
    return this.projects.delete(id);
  }

  async getTimeEntries(userId: number, projectId?: number): Promise<TimeEntry[]> {
    return Array.from(this.timeEntries.values()).filter(
      entry => entry.userId === userId && (!projectId || entry.projectId === projectId)
    );
  }

  async createTimeEntry(timeEntryData: InsertTimeEntry & { userId: number }): Promise<TimeEntry> {
    const id = this.currentId++;
    const timeEntry: TimeEntry = {
      ...timeEntryData,
      id,
      createdAt: new Date(),
    };
    this.timeEntries.set(id, timeEntry);
    return timeEntry;
  }

  async getInvoices(userId: number): Promise<Invoice[]> {
    return Array.from(this.invoices.values()).filter(
      invoice => invoice.userId === userId
    );
  }

  async createInvoice(invoiceData: InsertInvoice & { userId: number }): Promise<Invoice> {
    const id = this.currentId++;
    const invoice: Invoice = {
      ...invoiceData,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.invoices.set(id, invoice);
    return invoice;
  }

  async updateInvoiceStatus(id: number, userId: number, status: string): Promise<Invoice | undefined> {
    const invoice = this.invoices.get(id);
    if (!invoice || invoice.userId !== userId) return undefined;
    
    const updated = { ...invoice, status, updatedAt: new Date() };
    this.invoices.set(id, updated);
    return updated;
  }

  async getExpenses(userId: number): Promise<Expense[]> {
    return Array.from(this.expenses.values()).filter(
      expense => expense.userId === userId
    );
  }

  async createExpense(expenseData: InsertExpense & { userId: number }): Promise<Expense> {
    const id = this.currentId++;
    const expense: Expense = {
      ...expenseData,
      id,
      createdAt: new Date(),
    };
    this.expenses.set(id, expense);
    return expense;
  }

  async getTasks(userId: number, projectId?: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      task => task.userId === userId && (!projectId || task.projectId === projectId)
    );
  }

  async createTask(taskData: InsertTask & { userId: number }): Promise<Task> {
    const id = this.currentId++;
    const task: Task = {
      ...taskData,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTaskStatus(id: number, userId: number, status: string): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task || task.userId !== userId) return undefined;
    
    const updated = { ...task, status, updatedAt: new Date() };
    this.tasks.set(id, updated);
    return updated;
  }

  async getFiles(userId: number, projectId?: number): Promise<File[]> {
    return Array.from(this.files.values()).filter(
      file => file.userId === userId && (!projectId || file.projectId === projectId)
    );
  }

  async createFile(fileData: InsertFile & { userId: number }): Promise<File> {
    const id = this.currentId++;
    const file: File = {
      ...fileData,
      id,
      createdAt: new Date(),
    };
    this.files.set(id, file);
    return file;
  }

  async getUserScripts(userId: number): Promise<UserScript[]> {
    return Array.from(this.userScripts.values()).filter(
      script => script.userId === userId
    );
  }

  async createUserScript(scriptData: InsertUserScript & { userId: number }): Promise<UserScript> {
    const id = this.currentId++;
    const script: UserScript = {
      ...scriptData,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.userScripts.set(id, script);
    return script;
  }

  async updateUserScript(id: number, userId: number, scriptData: Partial<InsertUserScript>): Promise<UserScript | undefined> {
    const script = this.userScripts.get(id);
    if (!script || script.userId !== userId) return undefined;
    
    const updated = { ...script, ...scriptData, updatedAt: new Date() };
    this.userScripts.set(id, updated);
    return updated;
  }

  async getDashboardStats(userId: number): Promise<{
    outstandingRevenue: number;
    activeProjects: number;
    weeklyHours: number;
    filesOrganized: number;
    recentInvoices: Array<{ description: string; amount: number; type: 'income' | 'expense' }>;
    nextTasks: Array<{ title: string; priority: 'low' | 'medium' | 'high' }>;
    recentFiles: Array<{ name: string; type: string }>;
  }> {
    const userInvoices = await this.getInvoices(userId);
    const userProjects = await this.getProjects(userId);
    const userTasks = await this.getTasks(userId);
    const userFiles = await this.getFiles(userId);
    const userExpenses = await this.getExpenses(userId);

    const outstandingRevenue = userInvoices
      .filter(inv => inv.status === 'sent')
      .reduce((sum, inv) => sum + parseFloat(inv.amount), 0);

    const activeProjects = userProjects.filter(p => p.status === 'active').length;

    const recentInvoices = [
      ...userInvoices.slice(0, 2).map(inv => ({
        description: `${inv.clientName} invoice`,
        amount: parseFloat(inv.amount),
        type: 'income' as const
      })),
      ...userExpenses.slice(0, 1).map(exp => ({
        description: exp.description,
        amount: parseFloat(exp.amount),
        type: 'expense' as const
      }))
    ];

    const nextTasks = userTasks
      .filter(task => task.status === 'pending')
      .slice(0, 3)
      .map(task => ({
        title: task.title,
        priority: task.priority as 'low' | 'medium' | 'high'
      }));

    const recentFiles = userFiles.slice(0, 3).map(file => ({
      name: file.name,
      type: file.type
    }));

    return {
      outstandingRevenue,
      activeProjects,
      weeklyHours: 32.5,
      filesOrganized: userFiles.length,
      recentInvoices,
      nextTasks,
      recentFiles
    };
  }
}

export const storage = new MemStorage();
