# HelenKella Suite - Productivity Application

## Overview

The HelenKella Suite is a modern web application built as a productivity suite for self-employed individuals and small businesses. It consists of four main modules: Ledger (financial management), Agenda (time & task management), Docket (file organization), and Arsenal (upgrades marketplace). The application follows a philosophy of user ownership, no subscriptions, and ethical design principles.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system and CSS variables
- **State Management**: TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Design**: RESTful API with JSON responses
- **Development Server**: Custom Vite integration for SSR-like development experience

## Key Components

### Core Applications
1. **Dashboard**: Central hub showing overview statistics and quick access to all tools
2. **Ledger**: Financial management including invoicing, expense tracking, and revenue analytics
3. **Agenda**: Time tracking and task management with project organization
4. **Docket**: File and client organization system
5. **Arsenal**: Marketplace for optional upgrades and power-ups

### UI System
- **Design System**: Custom theme based on Tailwind with semantic color tokens
- **Component Library**: Comprehensive set of reusable components using Radix UI
- **Typography**: Consistent font scaling and spacing
- **Icons**: Lucide React icon library
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts

## Data Flow

### Client-Server Communication
- **API Layer**: Centralized API requests through custom query client
- **Error Handling**: Comprehensive error boundaries and user feedback
- **Loading States**: Skeleton screens and loading indicators
- **Caching**: Intelligent query caching with TanStack Query

### Data Validation
- **Schema Validation**: Drizzle-Zod integration for type-safe database operations
- **Runtime Type Safety**: Full TypeScript coverage from database to UI

## External Dependencies

### Database
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL with Neon serverless hosting
- **Migrations**: Drizzle Kit for schema migrations
- **Connection**: @neondatabase/serverless for optimized connections

### UI and Styling
- **Component Primitives**: Radix UI for accessible, unstyled components
- **CSS Framework**: Tailwind CSS for utility-first styling
- **Icons**: Lucide React for consistent iconography
- **Animations**: CSS transitions and Tailwind animation utilities

### Development Tools
- **Build System**: Vite with React plugin and custom configurations
- **Type Checking**: TypeScript with strict mode enabled
- **Development Experience**: Replit-specific plugins for enhanced development

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds the React application to `dist/public`
- **Backend**: esbuild bundles the Express server to `dist/index.js`
- **Asset Handling**: Static assets served from the client directory

### Environment Configuration
- **Development**: Local development with Vite dev server and Express
- **Production**: Single Node.js process serving both API and static files
- **Database**: Environment-based connection strings for different deployment stages

### Runtime Requirements
- **Node.js**: ES modules support with modern JavaScript features
- **Database**: PostgreSQL connection via environment variables
- **Storage**: File system access for static asset serving

The architecture emphasizes developer experience, type safety, and user ownership while maintaining a clean separation between client and server concerns. The application is designed to be self-contained and deployable as a single unit while supporting the philosophical goals of user sovereignty and ethical technology design.