# Chaos Merch Generator

This is a self-contained HTML/CSS/JS app designed for chaotic merch generation with neurodivergent flavor.

## Deploy via Netlify (no login required)

1. Zip the folder
2. Visit https://app.netlify.com/drop
3. Drag and drop the zip to deploy instantly

Enjoy your unhinged printable planner quotes and sticker vibes.
