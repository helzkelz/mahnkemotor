export default function Lorefront() {
  return (
    <main>
      <h1>Lorefront</h1>
      <p>Chaos tech and gamedev branch. Coming soon.</p>
    </main>
  );
}