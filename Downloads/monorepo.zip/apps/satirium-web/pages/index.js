export default function Satirium() {
  return (
    <main>
      <h1>The Satirium</h1>
      <p>Satirical critique and gamification. Coming soon.</p>
    </main>
  );
}