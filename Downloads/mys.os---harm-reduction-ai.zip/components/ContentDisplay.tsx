import React from 'react';
import { Content } from '../types';

interface ContentDisplayProps {
  content: Content;
}

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="mb-8">
    <h2 className="text-2xl font-bold text-white border-b-2 border-green-900/50 pb-2 mb-4">{title}</h2>
    {children}
  </div>
);

const ContentDisplay: React.FC<ContentDisplayProps> = ({ content }) => {
  return (
    <div className="p-8 text-green-400 animate-fadeIn">
      <header className="mb-8">
        <h1 className="text-4xl font-bold text-white">{content.title}</h1>
        {content.codename && <p className="text-xl text-green-300">Codename: {content.codename}</p>}
        {content.class && <p className="text-lg text-green-500">Class: {content.class}</p>}
        {content.description && <p className="mt-4 text-green-300/90">{content.description}</p>}
      </header>

      {content.profile && (
        <Section title="🧪 Chemical Profile">
          <ul className="space-y-2 list-inside list-disc marker:text-green-600">
            {content.profile.map((item, index) => <li key={index}>{item}</li>)}
          </ul>
        </Section