
import os
from browserbase import Browserbase
from dotenv import load_dotenv

load_dotenv()

class BrowserAgent:
    def __init__(self):
        self.bb = Browserbase(api_key=os.getenv("BROWSERBASE_API_KEY"))
        self.project_id = os.getenv("BROWSERBASE_PROJECT_ID")
        self.session = None
        self.tab = None

    def start_session(self, headless=False, record_video=True):
        config = {
            "browser": "chrome",
            "device": "desktop",
            "record_video": record_video,
            "timeout": 120000,
            "headless": headless
        }
        self.session = self.bb.sessions.create(project_id=self.project_id, **config)
        print("✅ Session started:", self.session["id"])

    def open_tab(self):
        if not self.session:
            raise Exception("Session not started.")
        self.tab = self.bb.tabs.create(session_id=self.session["id"])
        print("🆕 Tab opened:", self.tab["id"])

    def go_to(self, url):
        print(f"🌍 Navigating to {url}")
        self.bb.tabs.navigate(session_id=self.session["id"], tab_id=self.tab["id"], url=url)

    def wait_for(self, selector):
        print(f"⏳ Waiting for selector: {selector}")
        self.bb.tabs.wait_for_selector(session_id=self.session["id"], tab_id=self.tab["id"], selector=selector)

    def click(self, selector):
        print(f"🖱️ Clicking: {selector}")
        self.bb.tabs.click(session_id=self.session["id"], tab_id=self.tab["id"], selector=selector)

    def type(self, selector, text):
        print(f"⌨️ Typing into {selector}: {text}")
        self.bb.tabs.type(session_id=self.session["id"], tab_id=self.tab["id"], selector=selector, text=text)

    def screenshot(self, path="screenshot.png"):
        print(f"📸 Capturing screenshot to {path}")
        self.bb.tabs.screenshot(session_id=self.session["id"], tab_id=self.tab["id"], path=path)

    def end_session(self):
        print("💥 Ending session")
        if self.session:
            self.bb.sessions.delete(session_id=self.session["id"])
            self.session = None
            self.tab = None

if __name__ == "__main__":
    agent = BrowserAgent()
    agent.start_session()
    agent.open_tab()
    agent.go_to("https://helenkella.com")
    agent.wait_for("h1")
    agent.screenshot("helenkella_home.png")
    agent.end_session()
