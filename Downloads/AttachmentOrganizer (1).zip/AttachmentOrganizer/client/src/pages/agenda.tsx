import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Plus, Clock, CheckSquare } from "lucide-react";

export default function Agenda() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
              <Calendar className="text-blue-600 w-6 h-6" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Agenda</h1>
              <p className="text-slate-600">Time & Task Management</p>
            </div>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline">
              <Clock className="w-4 h-4 mr-2" />
              Start Timer
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Task
            </Button>
          </div>
        </div>

        {/* Time Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Today</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">6.5h</div>
              <p className="text-xs text-slate-500">3 projects</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">This Week</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-700">32.5h</div>
              <p className="text-xs text-slate-500">Target: 40h</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Completed Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600">24</div>
              <p className="text-xs text-slate-500">This week</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Avg. Focus Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">2.3h</div>
              <p className="text-xs text-slate-500">Per session</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Today's Tasks */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckSquare className="w-5 h-5 mr-2 text-blue-600" />
                Today's Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-3 p-3 border border-slate-200 rounded-lg">
                  <input type="checkbox" className="w-4 h-4 text-blue-600 rounded" />
                  <div className="flex-1">
                    <h4 className="font-medium text-slate-900">Review client wireframes</h4>
                    <p className="text-sm text-slate-500">Acme Corp Project • High Priority</p>
                  </div>
                  <div className="text-xs text-slate-500">2h est.</div>
                </div>

                <div className="flex items-center space-x-3 p-3 border border-slate-200 rounded-lg">
                  <input type="checkbox" className="w-4 h-4 text-blue-600 rounded" />
                  <div className="flex-1">
                    <h4 className="font-medium text-slate-900">Send project proposal</h4>
                    <p className="text-sm text-slate-500">New Client • Medium Priority</p>
                  </div>
                  <div className="text-xs text-slate-500">1h est.</div>
                </div>

                <div className="flex items-center space-x-3 p-3 border border-slate-200 rounded-lg">
                  <input type="checkbox" checked className="w-4 h-4 text-blue-600 rounded" />
                  <div className="flex-1">
                    <h4 className="font-medium text-slate-900 line-through">Weekly planning session</h4>
                    <p className="text-sm text-slate-500">Personal • Low Priority</p>
                  </div>
                  <div className="text-xs text-emerald-600">Completed</div>
                </div>

                <div className="flex items-center space-x-3 p-3 border border-slate-200 rounded-lg">
                  <input type="checkbox" className="w-4 h-4 text-blue-600 rounded" />
                  <div className="flex-1">
                    <h4 className="font-medium text-slate-900">Update portfolio website</h4>
                    <p className="text-sm text-slate-500">Personal • Low Priority</p>
                  </div>
                  <div className="text-xs text-slate-500">3h est.</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Time Tracking */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2 text-blue-600" />
                Active Session
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <div className="text-4xl font-bold text-blue-600 mb-2">01:23:45</div>
                <p className="text-slate-600 mb-4">Working on: Review client wireframes</p>
                <div className="flex justify-center space-x-4">
                  <Button className="bg-red-600 hover:bg-red-700">Stop</Button>
                  <Button variant="outline">Pause</Button>
                </div>
              </div>
              
              <div className="border-t pt-4 mt-4">
                <h4 className="font-medium text-slate-700 mb-3">Recent Sessions</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Logo design work</span>
                    <span className="font-medium">2h 15m</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Client consultation</span>
                    <span className="font-medium">1h 30m</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Email & admin</span>
                    <span className="font-medium">45m</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
