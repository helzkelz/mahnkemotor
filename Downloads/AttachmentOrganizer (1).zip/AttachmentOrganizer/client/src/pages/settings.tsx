import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings as SettingsIcon, User, Bell, Shield, Database, Code } from "lucide-react";

export default function Settings() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center">
            <SettingsIcon className="text-slate-600 w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Settings</h1>
            <p className="text-slate-600">Configure your HelenKella Suite</p>
          </div>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="profile" className="flex items-center space-x-2">
              <User className="w-4 h-4" />
              <span>Profile</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center space-x-2">
              <Bell className="w-4 h-4" />
              <span>Notifications</span>
            </TabsTrigger>
            <TabsTrigger value="privacy" className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Privacy</span>
            </TabsTrigger>
            <TabsTrigger value="data" className="flex items-center space-x-2">
              <Database className="w-4 h-4" />
              <span>Data</span>
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center space-x-2">
              <Code className="w-4 h-4" />
              <span>Advanced</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input id="firstName" defaultValue="Alex" />
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input id="lastName" defaultValue="Johnson" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue="alex@example.com" />
                </div>
                <div>
                  <Label htmlFor="company">Company</Label>
                  <Input id="company" defaultValue="Freelance Design Studio" />
                </div>
                <div>
                  <Label htmlFor="timezone">Timezone</Label>
                  <Input id="timezone" defaultValue="America/New_York" />
                </div>
                <Button className="bg-emerald-600 hover:bg-emerald-700">Save Changes</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Invoice Reminders</h4>
                    <p className="text-sm text-slate-500">Get notified when invoices are due</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Task Notifications</h4>
                    <p className="text-sm text-slate-500">Reminders for upcoming tasks and deadlines</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Time Tracking Alerts</h4>
                    <p className="text-sm text-slate-500">Break reminders and focus session alerts</p>
                  </div>
                  <Switch />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">File Sync Status</h4>
                    <p className="text-sm text-slate-500">Notifications about file uploads and syncing</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Weekly Reports</h4>
                    <p className="text-sm text-slate-500">Summary of your productivity and earnings</p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="privacy">
            <Card>
              <CardHeader>
                <CardTitle>Privacy & Security</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-200">
                  <h4 className="font-medium text-emerald-800 mb-2">Your Data Stays Yours</h4>
                  <p className="text-sm text-emerald-700">
                    All your data is stored locally or in your own cloud storage. We never access, analyze, or sell your information.
                  </p>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Anonymous Usage Analytics</h4>
                    <p className="text-sm text-slate-500">Help improve the software with anonymous usage data</p>
                  </div>
                  <Switch />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Crash Reporting</h4>
                    <p className="text-sm text-slate-500">Send crash reports to help fix bugs (no personal data)</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium">Data Export</h4>
                  <p className="text-sm text-slate-500">Export all your data in standard formats</p>
                  <Button variant="outline">Export All Data</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="data">
            <Card>
              <CardHeader>
                <CardTitle>Data & Storage</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-medium text-slate-900">Local Storage</h4>
                    <p className="text-2xl font-bold text-slate-700 mt-2">2.4 GB</p>
                    <p className="text-sm text-slate-500">Used on this device</p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-medium text-slate-900">Projects</h4>
                    <p className="text-2xl font-bold text-slate-700 mt-2">12</p>
                    <p className="text-sm text-slate-500">Active projects</p>
                  </div>
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <h4 className="font-medium text-slate-900">Files</h4>
                    <p className="text-2xl font-bold text-slate-700 mt-2">147</p>
                    <p className="text-sm text-slate-500">Total files managed</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h4 className="font-medium">Backup Options</h4>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start">
                      Create Local Backup
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      Restore from Backup
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      Schedule Automatic Backups
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium">Data Cleanup</h4>
                  <p className="text-sm text-slate-500">Remove temporary files and optimize storage</p>
                  <Button variant="outline">Clean Up Data</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="advanced">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-slate-900 text-white p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Scripts Folder Location</h4>
                  <p className="text-sm text-slate-300 mb-3">~/Documents/HelenKella/Scripts</p>
                  <Button variant="outline" className="text-slate-900 bg-white hover:bg-slate-100">
                    Open Scripts Folder
                  </Button>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Developer Mode</h4>
                    <p className="text-sm text-slate-500">Enable advanced scripting and customization features</p>
                  </div>
                  <Switch />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Beta Features</h4>
                    <p className="text-sm text-slate-500">Try experimental features before they're released</p>
                  </div>
                  <Switch />
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium">API Configuration</h4>
                  <p className="text-sm text-slate-500">Configure integrations and API keys</p>
                  <Button variant="outline">Manage API Keys</Button>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium">Reset to Defaults</h4>
                  <p className="text-sm text-slate-500">Reset all settings to their default values</p>
                  <Button variant="destructive">Reset Settings</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
