import { Header } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { FolderOpen, Plus, Search, Upload, FileText, FileImage, File } from "lucide-react";

export default function Docket() {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
              <FolderOpen className="text-purple-600 w-6 h-6" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Docket</h1>
              <p className="text-slate-600">File & Client Organization</p>
            </div>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline">
              <Upload className="w-4 h-4 mr-2" />
              Upload
            </Button>
            <Button className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              New Folder
            </Button>
          </div>
        </div>

        {/* File Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Total Files</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">147</div>
              <p className="text-xs text-slate-500">Across 12 projects</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Storage Used</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-700">2.4 GB</div>
              <p className="text-xs text-slate-500">of 10 GB available</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Recent Uploads</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-emerald-600">8</div>
              <p className="text-xs text-slate-500">This week</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">Shared Files</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">23</div>
              <p className="text-xs text-slate-500">With clients</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* File Browser */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>File Browser</CardTitle>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                      <Input
                        placeholder="Search files..."
                        className="pl-10 w-64"
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {/* Folders */}
                  <div className="flex items-center space-x-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer">
                    <FolderOpen className="w-5 h-5 text-purple-500" />
                    <div className="flex-1">
                      <h4 className="font-medium text-slate-900">Acme Corp Project</h4>
                      <p className="text-sm text-slate-500">12 files • Updated 2 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer">
                    <FolderOpen className="w-5 h-5 text-purple-500" />
                    <div className="flex-1">
                      <h4 className="font-medium text-slate-900">TechStart Consulting</h4>
                      <p className="text-sm text-slate-500">8 files • Updated yesterday</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer">
                    <FolderOpen className="w-5 h-5 text-purple-500" />
                    <div className="flex-1">
                      <h4 className="font-medium text-slate-900">Local Bakery</h4>
                      <p className="text-sm text-slate-500">5 files • Updated 3 days ago</p>
                    </div>
                  </div>

                  {/* Files */}
                  <div className="border-t pt-4 mt-4">
                    <div className="flex items-center space-x-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer">
                      <File className="w-5 h-5 text-red-500" />
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-900">Brand Guidelines v2.pdf</h4>
                        <p className="text-sm text-slate-500">2.4 MB • Modified today</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer">
                      <FileImage className="w-5 h-5 text-blue-500" />
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-900">Logo Concepts.sketch</h4>
                        <p className="text-sm text-slate-500">8.7 MB • Modified yesterday</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer">
                      <FileText className="w-5 h-5 text-green-500" />
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-900">Project Contract.docx</h4>
                        <p className="text-sm text-slate-500">156 KB • Modified 2 days ago</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3 p-3 hover:bg-slate-50 rounded-lg cursor-pointer">
                      <FileImage className="w-5 h-5 text-blue-500" />
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-900">Website Mockup.fig</h4>
                        <p className="text-sm text-slate-500">12.3 MB • Modified 3 days ago</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Activity */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Upload className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">Uploaded Brand Guidelines v2.pdf</p>
                      <p className="text-xs text-slate-500">2 hours ago</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <FileText className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">Created new folder: Q1 2024 Reports</p>
                      <p className="text-xs text-slate-500">Yesterday</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                      <FileImage className="w-4 h-4 text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">Shared Logo Concepts with client</p>
                      <p className="text-xs text-slate-500">2 days ago</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                      <File className="w-4 h-4 text-red-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">Exported invoice as PDF</p>
                      <p className="text-xs text-slate-500">3 days ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Files
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Folder
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Search className="w-4 h-4 mr-2" />
                    Advanced Search
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
