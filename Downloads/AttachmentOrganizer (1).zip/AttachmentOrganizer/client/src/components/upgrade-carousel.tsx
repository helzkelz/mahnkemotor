import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { PaymentOptions } from "@/components/payment-options";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";

interface UpgradeItem {
  title: string;
  price: string;
  features: string[];
  buttonText: string;
  category: string;
  description?: string;
  isPopular?: boolean;
}

interface UpgradeCarouselProps {
  items: UpgradeItem[];
  title: string;
  subtitle?: string;
}

export function UpgradeCarousel({ items, title, subtitle }: UpgradeCarouselProps) {
  const [selectedItem, setSelectedItem] = useState<UpgradeItem | null>(null);

  return (
    <div className="mb-12">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">{title}</h2>
        {subtitle && <p className="text-slate-600">{subtitle}</p>}
      </div>

      <Carousel
        opts={{
          align: "start",
          loop: true,
        }}
        className="w-full"
      >
        <CarouselContent className="-ml-2 md:-ml-4">
          {items.map((item, index) => (
            <CarouselItem key={index} className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
              <Card className={`h-full transition-all duration-200 hover:shadow-lg ${
                item.isPopular ? 'border-emerald-500 bg-gradient-to-br from-emerald-50 to-blue-50' : 'border-slate-200'
              }`}>
                <CardContent className="p-6 flex flex-col h-full">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-semibold text-slate-900">{item.title}</h3>
                        {item.isPopular && (
                          <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                            Popular
                          </Badge>
                        )}
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {item.category}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <span className="text-xl font-bold text-slate-900">{item.price}</span>
                    </div>
                  </div>

                  {item.description ? (
                    <p className="text-sm text-slate-600 mb-4 flex-1">{item.description}</p>
                  ) : (
                    <ul className="text-sm text-slate-600 space-y-1 mb-4 flex-1">
                      {item.features.slice(0, 3).map((feature, idx) => (
                        <li key={idx}>• {feature}</li>
                      ))}
                      {item.features.length > 3 && (
                        <li className="text-slate-400">+ {item.features.length - 3} more...</li>
                      )}
                    </ul>
                  )}

                  <Dialog>
                    <DialogTrigger asChild>
                      <Button 
                        className="w-full" 
                        variant={item.isPopular ? "default" : "outline"}
                        onClick={() => setSelectedItem(item)}
                      >
                        {item.buttonText}
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <PaymentOptions 
                        itemName={item.title} 
                        price={item.price} 
                      />
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>
    </div>
  );
}