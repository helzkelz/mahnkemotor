import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string;
  icon: LucideIcon;
  color?: "emerald" | "slate";
}

export function StatCard({ title, value, icon: Icon, color = "slate" }: StatCardProps) {
  const iconColorClass = color === "emerald" ? "text-emerald-500" : "text-slate-500";
  const valueColorClass = color === "emerald" ? "text-emerald-600" : "text-slate-700";

  return (
    <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-slate-600">{title}</p>
          <p className={`text-2xl font-bold ${valueColorClass}`}>{value}</p>
        </div>
        <Icon className={`${iconColorClass} text-xl w-5 h-5`} />
      </div>
    </div>
  );
}
