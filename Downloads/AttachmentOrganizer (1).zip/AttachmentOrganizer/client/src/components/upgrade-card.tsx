import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { PaymentOptions } from "@/components/payment-options";
import { useState } from "react";

interface UpgradeCardProps {
  title: string;
  price: string;
  features: string[];
  type?: "normal" | "highlighted" | "service";
  buttonText?: string;
  buttonVariant?: "default" | "secondary" | "outline";
  description?: string;
  isRecurring?: boolean;
}

export function UpgradeCard({ 
  title, 
  price, 
  features, 
  type = "normal",
  buttonText = "Learn More",
  buttonVariant = "secondary",
  description,
  isRecurring = false
}: UpgradeCardProps) {
  const [isOpen, setIsOpen] = useState(false);
  
  const cardClasses = {
    normal: "border border-slate-200 hover:border-slate-300",
    highlighted: "border border-emerald-200 bg-emerald-50",
    service: "border border-orange-200 bg-orange-50"
  };

  const buttonClasses = {
    default: "bg-emerald-600 hover:bg-emerald-700 text-white",
    secondary: "bg-slate-100 hover:bg-slate-200 text-slate-700",
    outline: "bg-orange-100 hover:bg-orange-200 text-orange-700"
  };

  const isPurchasable = buttonText.includes("Buy") || buttonText.includes("Upgrade") || buttonText.includes("Add to");

  return (
    <div className={`rounded-xl p-4 transition-colors ${cardClasses[type]}`}>
      <div className="flex items-center justify-between mb-3">
        <h4 className="font-semibold text-slate-900">{title}</h4>
        <div className="text-right">
          <span className={`text-lg font-bold ${type === 'service' ? 'text-orange-600' : 'text-slate-700'}`}>
            {price}
          </span>
          {isRecurring && <span className="text-sm text-slate-500">/year</span>}
        </div>
      </div>
      
      {description ? (
        <p className="text-sm text-slate-600 mb-3">{description}</p>
      ) : (
        <ul className="text-sm text-slate-600 space-y-1 mb-4">
          {features.map((feature, index) => (
            <li key={index}>• {feature}</li>
          ))}
        </ul>
      )}
      
      {type === "service" && (
        <div className="flex items-center space-x-2 text-xs text-orange-700 mb-3">
          <span className="w-3 h-3 rounded-full bg-orange-400 flex items-center justify-center">
            <span className="text-white text-xs">i</span>
          </span>
          <span>Honest pricing, no markup</span>
        </div>
      )}
      
      {isPurchasable ? (
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button 
              className={`w-full text-sm font-medium transition-colors ${buttonClasses[buttonVariant]}`}
              variant={buttonVariant === "default" ? "default" : "outline"}
            >
              {buttonText}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <PaymentOptions 
              itemName={title} 
              price={price} 
              onClose={() => setIsOpen(false)} 
            />
          </DialogContent>
        </Dialog>
      ) : (
        <Button 
          className={`w-full text-sm font-medium transition-colors ${buttonClasses[buttonVariant]}`}
          variant={buttonVariant === "default" ? "default" : "outline"}
        >
          {buttonText}
        </Button>
      )}
    </div>
  );
}
