import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CreditCard, Smartphone, DollarSign } from "lucide-react";

interface PaymentOptionsProps {
  itemName: string;
  price: string;
  onClose?: () => void;
}

export function PaymentOptions({ itemName, price, onClose }: PaymentOptionsProps) {
  const handleCashAppPayment = () => {
    // In a real app, this would integrate with CashApp API
    window.open(`https://cash.app/$helenkella/${price.replace('$', '')}`, '_blank');
  };

  const handlePayPalPayment = () => {
    // In a real app, this would integrate with PayPal API
    window.open(`https://paypal.me/helenkella/${price.replace('$', '')}`, '_blank');
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center space-x-2">
          <DollarSign className="w-5 h-5 text-emerald-600" />
          <span>Purchase {itemName}</span>
        </CardTitle>
        <CardDescription>
          <Badge variant="secondary" className="text-lg font-semibold">
            {price}
          </Badge>
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="text-sm text-slate-600 text-center mb-6">
          Choose your preferred payment method:
        </div>
        
        {/* CashApp Option */}
        <Button 
          onClick={handleCashAppPayment}
          variant="default" 
          className="w-full bg-green-600 hover:bg-green-700 text-white"
          size="lg"
        >
          <Smartphone className="w-5 h-5 mr-3" />
          Pay with CashApp
        </Button>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <Separator className="w-full" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white px-2 text-slate-500">or</span>
          </div>
        </div>

        {/* PayPal Option */}
        <Button 
          onClick={handlePayPalPayment}
          variant="outline" 
          className="w-full border-blue-600 text-blue-600 hover:bg-blue-50"
          size="lg"
        >
          <CreditCard className="w-5 h-5 mr-3" />
          Pay with PayPal
        </Button>

        <div className="text-xs text-slate-500 text-center mt-4">
          <p>✓ Secure payment processing</p>
          <p>✓ One-time purchase - own forever</p>
          <p>✓ No subscription required</p>
        </div>

        {onClose && (
          <Button 
            onClick={onClose}
            variant="ghost" 
            className="w-full mt-4"
          >
            Cancel
          </Button>
        )}
      </CardContent>
    </Card>
  );
}