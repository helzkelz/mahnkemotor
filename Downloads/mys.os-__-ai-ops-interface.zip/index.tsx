
import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, Chat } from '@google/genai';

// --- Types ---
type Message = {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  isThinking?: boolean;
};

type TriageItem = {
    id: string;
    label: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    items?: TriageItem[];
};

// --- SVG Icons ---
const BeakerIcon = ({ className = "w-6 h-6" }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4.5 3h15M6 3v12c0 3.3 2.7 6 6 6s6-2.7 6-6V3M6 14h12"/></svg>;
const ShieldIcon = ({ className = "w-6 h-6" }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>;
const EyeIcon = ({ className = "w-6 h-6" }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>;
const BookIcon = ({ className = "w-6 h-6" }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20v-1H6.5a2.5 2.5 0 0 1 0-5H20V6H6.5a2.5 2.5 0 0 1 0-5H20V2H6.5A2.5 2.5 0 0 1 4 4.5v15z"/></svg>;
const HeartIcon = ({ className = "w-6 h-6" }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>;
const FlaskIcon = ({ className = "w-6 h-6" }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M10 2v7.31M14 9.31V2M8.5 2h7M14 9.31l-5.71 5.71a2.83 2.83 0 0 0 0 4L14 24l5.71-5.71a2.83 2.83 0 0 0 0-4L14 9.31z"/></svg>;
const ArrowLeftIcon = ({ className = "w-6 h-6" }) => <svg xmlns="http://www.w3.org/2000/svg" className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5"/><path d="m12 19-7-7 7-7"/></svg>;
const HamburgerIcon = () => (
     <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M4 6H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M4 12H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M4 18H20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);

// --- UI Components ---
const LoadingDots = () => (
    <div className="flex space-x-1">
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
        <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
    </div>
);

const SystemStatus = ({ isLoading, error }: { isLoading: boolean; error: string | null }) => {
    let statusText = "Online";
    let colorClass = "bg-green-500/20 text-green-300";

    if (error) {
        statusText = "Error";
        colorClass = "bg-red-500/20 text-red-300";
    } else if (isLoading) {
        statusText = "Processing";
        colorClass = "bg-blue-500/20 text-blue-300";
    }

    return (
        <div className={`flex items-center space-x-2 text-sm font-medium px-3 py-1 rounded-full ${colorClass}`}>
            <div className={`w-2 h-2 rounded-full ${colorClass.replace('/20','').replace('text-','bg-').replace('-300', '-500')}`}></div>
            <span>{statusText}</span>
        </div>
    );
};

// --- Data ---
const menuData: TriageItem[] = [
    {
        id: 'substances', label: 'Substance Analysis', description: 'Pharmacology, risks, and interactions', icon: BeakerIcon,
        items: [
            { id: 'depressants', label: 'Depressants', description: 'Alcohol, Opioids, Benzos...', icon: BeakerIcon, items: [{id: 'alcohol', label: 'Alcohol', description: '', icon: BeakerIcon}, {id: 'benzos', label: 'Benzodiazepines', description: '', icon: BeakerIcon}, {id: 'opioids', label: 'Opioids', description: '', icon: BeakerIcon}, {id: 'ghb', label: 'GHB', description: '', icon: BeakerIcon}, {id: 'fentanyl', label: 'Fentanyl', description: '', icon: BeakerIcon}] },
            { id: 'stimulants', label: 'Stimulants', description: 'Cocaine, Methamphetamine...', icon: BeakerIcon, items: [{id: 'cocaine', label: 'Cocaine', description: '', icon: BeakerIcon}, {id: 'meth', label: 'Methamphetamine', description: '', icon: BeakerIcon}] },
            { id: 'psychs', label: 'Psychedelics & Dissociatives', description: 'LSD, MDMA, Ketamine...', icon: BeakerIcon, items: [{id: 'lsd', label: 'LSD', description: '', icon: BeakerIcon}, {id: 'mdma', label: 'MDMA', description: '', icon: BeakerIcon}, {id: 'ketamine', label: 'Ketamine', description: '', icon: BeakerIcon}, {id: 'dxm', label: 'DXM', description: '', icon: BeakerIcon}] },
        ]
    },
    {
        id: 'rcs', label: 'Research Chemicals', description: 'Emerging compounds intelligence', icon: FlaskIcon,
        items: [
            { id: 'rc_benzos', label: 'RC Benzodiazepines', description: 'Clonazolam, Flubromazepam...', icon: FlaskIcon },
            { id: 'rc_stims', label: 'RC Stimulants', description: 'Hexen, A-PHP...', icon: FlaskIcon },
            { id: 'rc_psychs', label: 'RC Psychedelics', description: '1P-LSD, 4-AcO-DMT...', icon: FlaskIcon },
        ]
    },
    { id: 'protocols', label: 'Protocol Library', description: 'Harm reduction & response plans', icon: ShieldIcon, items: [{id: 'test_kits', label: 'Test Kits', description: '', icon: ShieldIcon}, {id: 'emergency', label: 'Emergency Response', description: '', icon: ShieldIcon}, {id: 'tapering', label: 'Tapering', description: '', icon: ShieldIcon}] },
    { id: 'fieldcraft', label: 'Fieldcraft', description: 'Operational survival tactics', icon: EyeIcon, items: [{id: 'stealth_lab', label: 'Stealth Lab', description: '', icon: EyeIcon}, {id: 'counter_surveillance', label: 'Counter-Surveillance', description: '', icon: EyeIcon}] },
    { id: 'intel', label: 'Intel Database', description: 'Glossaries and risk analysis', icon: BookIcon, items: [{id: 'glossary', label: 'Glossary', description: '', icon: BookIcon}, {id: 'red_flags', label: 'Supply Chain Red Flags', description: '', icon: BookIcon}] },
    { id: 'mental_health', label: 'Mental Health', description: 'Support and coping strategies', icon: HeartIcon, items: [{id: 'anxiety', label: 'Anxiety', description: '', icon: HeartIcon}, {id: 'depression', label: 'Depression', description: '', icon: HeartIcon}] }
];

// --- Main Components ---
const TriageCard = ({ item, onClick }: { item: TriageItem; onClick: (item: TriageItem) => void; }) => (
    <div onClick={() => onClick(item)} className="triage-card p-6 rounded-lg flex flex-col items-start text-left">
        <div className="p-3 bg-slate-700/50 rounded-lg mb-4">
            <item.icon className="w-8 h-8 text-blue-400" />
        </div>
        <h3 className="font-bold text-lg text-slate-100">{item.label}</h3>
        <p className="text-slate-400 text-sm">{item.description}</p>
    </div>
);

const Questionnaire = ({ onSelect }: { onSelect: (item: TriageItem) => void }) => {
    const [path, setPath] = useState<string[]>([]);
    
    const goBack = () => setPath(prev => prev.slice(0, -1));

    let currentItems: TriageItem[] = menuData;
    let currentTitle = "Triage & Intel";
    for (const key of path) {
        const found = currentItems?.find(i => i.id === key);
        currentItems = found?.items || [];
        currentTitle = found?.label || currentTitle;
    }

    const handleSelect = (item: TriageItem) => {
        if (item.items && item.items.length > 0) {
            setPath(prev => [...prev, item.id]);
        } else {
            onSelect(item);
        }
    };
    
    return (
        <div className="w-full max-w-5xl mx-auto p-4 md:p-8">
            <div className="flex items-center mb-6 fade-in">
                {path.length > 0 && (
                    <button onClick={goBack} className="mr-4 p-2 rounded-md text-slate-400 hover:text-white hover:bg-slate-700">
                        <ArrowLeftIcon className="w-6 h-6" />
                    </button>
                )}
                <h2 className="text-2xl md:text-3xl font-bold text-slate-100">{currentTitle}</h2>
            </div>
            <div className="triage-grid fade-in">
                {currentItems.map(item => (
                    <TriageCard key={item.id} item={item} onClick={handleSelect} />
                ))}
            </div>
        </div>
    );
};

const Sidebar = ({ isOpen, onMenuItemClick }: { isOpen: boolean, onMenuItemClick: (item: string) => void }) => (
    <aside className={`sidebar absolute top-0 left-0 h-full w-72 bg-slate-800 border-r border-slate-700 p-4 overflow-y-auto z-20 md:relative ${!isOpen && 'sidebar-hidden'}`}>
        <h2 className="text-xl font-bold text-slate-100 mb-6">Expert Mode</h2>
        {menuData.map((cat) => (
             <div key={cat.id} className="mb-4">
                 <h3 className="text-sm text-slate-500 font-semibold uppercase tracking-wider mb-2">{cat.label}</h3>
                 <ul className="space-y-1">
                 {cat.items?.map(item => (
                     <li key={item.id}>
                         <button onClick={() => onMenuItemClick(item.label)} className="w-full text-left cursor-pointer py-1.5 px-3 hover:bg-slate-700/80 rounded-md text-slate-300 hover:text-blue-400 transition-colors font-medium">
                            {item.label}
                         </button>
                     </li>
                 ))}
                 </ul>
             </div>
        ))}
    </aside>
);

const App = () => {
  const [appMode, setAppMode] = useState<'triage' | 'results'>('triage');
  const [chat, setChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    try {
      if (!process.env.API_KEY) throw new Error("API_KEY environment variable not set.");
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const chatInstance = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: 'You are HOLLOWPOINT, a tactical AI assistant for MYS.OS. Provide direct, data-driven intelligence for harm reduction, clandestine chemistry, and psychoactive survivability. No moralizing, no fluff—just survival intelligence.',
        },
      });
      setChat(chatInstance);
    } catch (e: any) {
      console.error(e);
      setError("Initialization failed: " + e.message);
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  const executeCommand = async (commandText: string, topicLabel: string) => {
    if (!commandText.trim() || isLoading || !chat) return;
    
    setAppMode('results');
    const userMessage: Message = { id: `user-${Date.now()}`, sender: 'user', text: `Intel Request: ${topicLabel}` };
    setMessages([userMessage]);
    setIsLoading(true);
    setError(null);

    const aiMessageId = `ai-${Date.now()}`;
    setMessages(prev => [...prev, { id: aiMessageId, sender: 'ai', text: '', isThinking: true }]);

    try {
      let fullResponse = '';
      const stream = await chat.sendMessageStream({ message: commandText });
      for await (const chunk of stream) {
        fullResponse += chunk.text;
        setMessages(prev => prev.map(msg => msg.id === aiMessageId ? { ...msg, text: fullResponse, isThinking: false } : msg));
      }
    } catch (e: any) {
      console.error(e);
      const errorMessage = `System Error: ${e.message || 'Failed to get response.'}`;
      setError(errorMessage);
      setMessages(prev => prev.map(msg => msg.id === aiMessageId ? { ...msg, text: errorMessage, isThinking: false } : msg));
    } finally {
      setIsLoading(false);
    }
  };

  const handleTriageSelect = (item: TriageItem) => {
    executeCommand(`Provide intelligence brief on: ${item.label}`, item.label);
  };
  
  const handleMenuItemClick = (itemLabel: string) => {
    executeCommand(`Provide intelligence brief on: ${itemLabel}`, itemLabel);
    if (window.innerWidth < 768) setIsSidebarOpen(false);
  };

  const startNewTriage = () => {
      setMessages([]);
      setError(null);
      setIsLoading(false);
      setAppMode('triage');
  }

  return (
    <div className="flex h-screen bg-slate-900 text-slate-200 font-sans">
      <Sidebar isOpen={isSidebarOpen} onMenuItemClick={handleMenuItemClick} />
      <div className="flex-1 flex flex-col h-screen">
        <header className="p-4 border-b border-slate-700 flex justify-between items-center text-sm flex-shrink-0 bg-slate-800/50 backdrop-blur-sm z-10">
            <div className="flex items-center">
                <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="mr-4 p-2 rounded-md text-slate-400 hover:text-white hover:bg-slate-700" aria-label="Toggle menu">
                    <HamburgerIcon/>
                </button>
                <h1 className="text-slate-100 font-bold text-lg hidden md:block">MYS.OS AI Interface</h1>
            </div>
            <SystemStatus isLoading={isLoading} error={error} />
        </header>

        <main className="flex-1 overflow-y-auto">
          {appMode === 'triage' ? (
              <Questionnaire onSelect={handleTriageSelect} />
          ) : (
            <div className="p-4 md:p-6 h-full">
              <div className="space-y-6 max-w-4xl mx-auto h-full">
                  {messages.map((msg) => (
                    <div key={msg.id} className={`flex items-end gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                      {msg.sender === 'user' ? (
                        <div className="bg-blue-600 text-white p-3 rounded-2xl rounded-br-md max-w-lg">
                          <p className="whitespace-pre-wrap">{msg.text}</p>
                        </div>
                      ) : (
                        <div className="bg-slate-700 text-slate-200 p-3 rounded-2xl rounded-bl-md max-w-lg">
                          {msg.isThinking ? <LoadingDots /> : <p className="whitespace-pre-wrap">{msg.text}</p>}
                        </div>
                      )}
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
              </div>
            </div>
          )}
        </main>

        {appMode === 'results' && (
            <footer className="p-4 border-t border-slate-700 flex-shrink-0 bg-slate-800">
              <div className="max-w-4xl mx-auto flex justify-center">
                <button 
                    onClick={startNewTriage}
                    className="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-6 rounded-lg transition-colors"
                >
                    Start New Triage
                </button>
              </div>
            </footer>
        )}
      </div>
    </div>
  );
};

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(<App />);
}
