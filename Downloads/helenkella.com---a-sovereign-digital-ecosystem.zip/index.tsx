/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

// --- Data for Cards ---
const INITIATIVES = [
  {
    id: 'mys-os',
    navTitle: 'mys.os',
    title: 'mys.os',
    description:
      'A one-size-fits-you personal operating system for neurodivergent minds. Reclaim your bandwidth with a system that adapts to you, not the other way around.',
    linkText: 'Explore the Initiative →',
  },
  {
    id: 'mysconduct',
    navTitle: 'Mysconduct',
    title: 'Mysconduct',
    description:
      'The high-consent platform for NSFW creators and their communities. An ethical, sovereign alternative to exploitative industry standards.',
    linkText: 'Explore the Initiative →',
  },
  {
    id: 'satirium',
    navTitle: 'The Satirium',
    title: 'The Satirium',
    description:
      'A social critique engine and IP generator where community resistance is channeled into a gamified, satirical art form.',
    linkText: 'Explore the Initiative →',
  },
  {
    id: 'helenhaus',
    navTitle: 'HelenHaus™ (B2B)',
    title: 'HelenHaus™',
    description:
      'The B2B licensing portal. We offer our OS, daemons, and ethical frameworks as white-label solutions for agencies and enterprises.',
    linkText: 'Explore the Initiative →',
  },
];

const PILLARS = {
  'mys-os': {
    title: 'mys.os',
    subtitle:
      'The One-Size-Fits-You Operating System. Built with neurodivergent-native design and a core of anti-punishment, trauma-informed logic.',
    accentColor: 'var(--cyan-light)',
    buttonClass: 'btn-cyan',
    buttonText: 'Begin Your Initiation',
    items: [
      {
        title: 'Neurodivergent-Native UX',
        description:
          'Features like Overload Recovery Mode, `hugboxd`, and `floatcatchd` are built-in to support your unique cognitive flow.',
      },
      {
        title: 'Consent-Based Execution',
        description:
          'Every action is gated by checks for cognitive cost and undoability. You are always in control.',
      },
      {
        title: 'Functionality Over Labels',
        description:
          "You define the outcome you need—like 'trauma reflection'—and the OS provides a personalized tool, not a generic app.",
      },
    ],
  },
  mysconduct: {
    title: 'Mysconduct',
    subtitle:
      'The high-consent platform where creators build their own worlds on their own terms. This is sovereignty, monetized.',
    accentColor: 'var(--fuchsia)',
    buttonClass: 'btn-fuchsia',
    buttonText: 'Enter the Space',
    items: [
      {
        title: 'Ethical Monetization',
        description:
          'From zines to subscriptions, we provide the tools for you to profit from your work without exploitative algorithms or opaque payment structures.',
      },
      {
        title: 'The Consent Engine',
        description:
          'Our `consentDaemon` and embedded UI flows ensure that every interaction is explicit, affirmative, and recorded, protecting both creators and audiences.',
      },
      {
        title: 'Creator Sovereignty',
        description:
          'This is your space. We provide the tools—you set the rules. No censorship of your expression, no stealing your data. Full autonomy.',
      },
    ],
  },
  satirium: {
    title: 'The Satirium',
    subtitle:
      'A social critique engine and IP generator where community resistance is channeled into a gamified, satirical art form.',
    accentColor: 'var(--cyan-light)',
    buttonClass: 'btn-cyan',
    buttonText: 'Join the Resistance',
    items: [
      {
        title: 'Gamified Critique',
        description:
          'Turn dissent into art and strategy. Earn reputation by deconstructing and satirizing broken systems.',
      },
      {
        title: 'Collective IP Generation',
        description:
          'Ideas and critiques are forged into valuable intellectual property, owned and governed by the community.',
      },
      {
        title: 'Resilience through Art',
        description:
          'A creative outlet for activism that avoids burnout by focusing on constructive, satirical expression.',
      },
    ],
  },
  helenhaus: {
    title: 'HelenHaus™ (B2B)',
    subtitle:
      'We offer our OS, daemons, and ethical frameworks as white-label solutions for agencies and enterprises.',
    accentColor: 'var(--fuchsia)',
    buttonClass: 'btn-fuchsia',
    buttonText: 'Inquire About Licensing',
    items: [
      {
        title: 'Ethical Frameworks',
        description:
          'Integrate our consent-based, trauma-informed logic into your products and services.',
      },
      {
        title: 'Sovereign Architecture',
        description:
          'Build resilient, user-centric systems with our battle-tested components like `consentDaemon`.',
      },
      {
        title: 'White-Label Solutions',
        description:
          'License mys.os and other platforms to offer your clients a truly humane digital experience.',
      },
    ],
  },
};

// --- Core Component Class ---
abstract class Component {
  protected element: HTMLElement;

  // Subclasses will implement this to create their specific element.
  protected abstract create(): HTMLElement;

  // Public method to get the element, creating it on first request.
  public getElement(): HTMLElement {
    if (!this.element) {
      this.element = this.create();
    }
    return this.element;
  }
}

// --- Page Components ---

class HomePage extends Component {
  protected create(): HTMLElement {
    const main = document.createElement('main');
    main.append(this.createHeroSection(), this.createEcosystemSection());
    return main;
  }

  private createHeroSection(): HTMLElement {
    const section = document.createElement('section');
    section.className = 'hero-section';

    const container = document.createElement('div');
    container.className = 'container';

    const title = document.createElement('h1');
    title.className = 'hero-title';
    title.textContent = 'A Sovereign OS for a Sovereign You.';

    const subtitle = document.createElement('p');
    subtitle.className = 'hero-subtitle';
    subtitle.textContent =
      'This is the hub for an ecosystem of tools, platforms, and movements designed to replace outdated, exploitative systems. We build with integrity, for your autonomy.';

    container.append(title, subtitle);
    section.appendChild(container);
    return section;
  }

  private createEcosystemSection(): HTMLElement {
    const section = document.createElement('section');
    section.id = 'ecosystem';
    section.className = 'section section-dark';

    const container = document.createElement('div');
    container.className = 'container';

    const title = document.createElement('h2');
    title.className = 'section-title';
    title.textContent = 'The HelenKella Ecosystem';

    const grid = document.createElement('div');
    grid.className = 'card-grid';

    INITIATIVES.forEach((item) => {
      const card = document.createElement('div');
      card.className = 'initiative-card';
      const cardTitle = document.createElement('h3');
      cardTitle.textContent = item.title;
      const cardDesc = document.createElement('p');
      cardDesc.textContent = item.description;
      const cardLink = document.createElement('a');
      cardLink.href = `/${item.id}`;
      cardLink.textContent = item.linkText;
      card.append(cardTitle, cardDesc, cardLink);
      grid.appendChild(card);
    });

    container.append(title, grid);
    section.appendChild(container);
    return section;
  }
}

class SubPage extends Component {
  private id: keyof typeof PILLARS;

  constructor(id: keyof typeof PILLARS) {
    super();
    this.id = id;
  }

  protected create(): HTMLElement {
    const data = PILLARS[this.id];
    const main = document.createElement('main');
    main.style.paddingTop = '8rem';

    const section = document.createElement('section');
    section.id = this.id;
    section.className = 'section';

    const container = document.createElement('div');
    container.className = 'container';
    container.style.maxWidth = '64rem';

    const header = document.createElement('div');
    header.className = 'text-center';
    const headerTitle = document.createElement('h1');
    headerTitle.style.fontSize = '3rem';
    headerTitle.style.fontWeight = '900';
    headerTitle.textContent = data.title;
    const headerSubtitle = document.createElement('p');
    headerSubtitle.style.cssText =
      'margin-top: 1rem; max-width: 42rem; margin-left: auto; margin-right: auto; font-size: 1.25rem; color: #d1d5db;';
    headerSubtitle.textContent = data.subtitle;
    header.append(headerTitle, headerSubtitle);

    const title = document.createElement('h2');
    title.className = 'section-title';
    title.style.marginTop = '4rem';
    title.textContent =
      this.id === 'mysconduct' ? 'Our Commitment' : 'Core Pillars';

    const grid = document.createElement('div');
    grid.className = 'card-grid pillar-grid';

    data.items.forEach((item) => {
      const card = document.createElement('div');
      card.className = 'pillar-card';
      const cardTitle = document.createElement('h3');
      cardTitle.style.color = data.accentColor;
      cardTitle.textContent = item.title;
      const cardDesc = document.createElement('p');
      cardDesc.textContent = item.description;
      card.append(cardTitle, cardDesc);
      grid.appendChild(card);
    });

    const ctaContainer = document.createElement('div');
    ctaContainer.className = 'text-center';
    const button = document.createElement('button');
    button.className = `cta-button ${data.buttonClass}`;
    button.textContent = data.buttonText;
    ctaContainer.appendChild(button);

    container.append(header, title, grid, ctaContainer);
    section.appendChild(container);
    main.appendChild(section);
    return main;
  }
}

// --- Layout Components ---

class Header extends Component {
  private navLinks: HTMLAnchorElement[] = [];

  protected create(): HTMLElement {
    const header = document.createElement('header');
    header.className = 'header';

    const container = document.createElement('div');
    container.className = 'container';

    const logoLink = document.createElement('a');
    logoLink.href = '/';
    logoLink.className = 'header-logo';
    logoLink.textContent = 'HelenKella.com';

    const nav = document.createElement('nav');
    nav.className = 'header-nav';
    this.navLinks = INITIATIVES.map((item) => {
      const link = document.createElement('a');
      link.href = `/${item.id}`;
      link.textContent = item.navTitle;
      if (item.id === 'helenhaus') {
        link.style.fontWeight = 'bold';
      }
      return link;
    });
    nav.append(...this.navLinks);

    const contactLink = document.createElement('a');
    contactLink.href = '#contact';
    contactLink.className = 'header-contact-btn';
    contactLink.textContent = 'Initiate Contact';

    container.append(logoLink, nav, contactLink);
    header.appendChild(container);
    return header;
  }

  public setActive(path: string) {
    this.navLinks.forEach((link) => {
      link.classList.remove('active');
      if (link.getAttribute('href') === path) {
        link.classList.add('active');
      }
    });
  }
}

class Footer extends Component {
  protected create(): HTMLElement {
    const footer = document.createElement('footer');
    footer.id = 'contact';
    footer.className = 'footer';

    const container = document.createElement('div');
    container.className = 'container';

    const p1 = document.createElement('p');
    p1.textContent =
      '© 2024 HelenKella Systems. Your Consciousness is Not a Product.';
    const p2 = document.createElement('p');
    p2.textContent = 'Building Keys, Not Cages.';

    container.append(p1, p2);
    footer.appendChild(container);
    return footer;
  }
}

// --- Router Class ---
type RouteHandler = () => Component;

class Router {
  private container: HTMLElement;
  private routes: Record<string, RouteHandler>;
  private isRouting = false;
  public onNavigate: (path: string) => void = () => {};

  constructor(container: HTMLElement, routes: Record<string, RouteHandler>) {
    this.container = container;
    this.routes = routes;
  }

  public navigate(path: string) {
    if (this.isRouting || path === window.location.pathname) return;
    window.history.pushState({}, '', path);
    this.resolve(path);
  }

  public async resolve(path = window.location.pathname) {
    if (this.isRouting) return;
    this.isRouting = true;

    document.body.classList.add('is-routing');

    await new Promise((resolve) => {
      const onTransitionEnd = () => {
        this.container.removeEventListener('transitionend', onTransitionEnd);
        resolve(null);
      };
      this.container.addEventListener('transitionend', onTransitionEnd, {
        once: true,
      });
    });

    // Clear existing content
    this.container.innerHTML = '';

    // Find the matching route
    const pageId = path.substring(1);
    let routeHandler = this.routes[path];
    if (!routeHandler && PILLARS.hasOwnProperty(pageId)) {
      routeHandler = () => new SubPage(pageId as keyof typeof PILLARS);
    }
    if (!routeHandler) {
      routeHandler = this.routes['/'];
      window.history.replaceState({}, '', '/');
      path = '/';
    }

    // Render new component
    const component = routeHandler();
    this.container.appendChild(component.getElement());

    this.onNavigate(path);
    window.scrollTo(0, 0);

    // This forces a reflow, allowing the fade-in transition to work
    window.requestAnimationFrame(() => {
      document.body.classList.remove('is-routing');
    });

    this.isRouting = false;
  }
}

// --- Main Application Class ---
class App {
  private root: HTMLElement;
  private header: Header;
  private router: Router;

  constructor(root: HTMLElement) {
    this.root = root;
    this.header = new Header();
    const mainContentContainer = document.createElement('div');
    mainContentContainer.id = 'page-content-wrapper';

    // Define routes
    const routes: Record<string, RouteHandler> = {
      '/': () => new HomePage(),
    };
    INITIATIVES.forEach((item) => {
      routes[`/${item.id}`] = () =>
        new SubPage(item.id as keyof typeof PILLARS);
    });

    this.router = new Router(mainContentContainer, routes);
    this.router.onNavigate = (path) => {
      this.header.setActive(path);
    };

    // Prepend header, append content container and footer
    this.root.prepend(this.header.getElement());
    this.root.appendChild(mainContentContainer);
    this.root.appendChild(new Footer().getElement());
  }

  public start() {
    this.router.resolve();
    window.addEventListener('popstate', () => this.router.resolve());
    this.root.addEventListener('click', this.handleNavigation.bind(this));
  }

  private handleNavigation(e: MouseEvent) {
    if (!(e.target instanceof Element)) return;
    const anchor = e.target.closest('a');

    if (
      !anchor ||
      anchor.target === '_blank' ||
      anchor.origin !== window.location.origin
    ) {
      return;
    }

    const href = anchor.getAttribute('href');
    if (href && href.startsWith('/')) {
      e.preventDefault();
      this.router.navigate(href);
    }
  }
}

new App(document.body).start();
