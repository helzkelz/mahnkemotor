# 🧠 HelenKella Godmode OS: The Anti-Platform for the Post-Platform Era

Welcome to the unified, canonical monorepo for HelenKella Godmode OS and all its branches—Mysconduct, Satirium, Lorefront, and beyond.

> If you’re working on any branch/platform, **start here, and all context will flow from this root.**

---

## 🌳 Monorepo Structure

```
/godmode-stack/
├── apps/
│   ├── dashboard/
│   ├── helenkella-web/
│   ├── mysconduct-web/
│   ├── satirium-web/
│   ├── lorefront-web/
│   └── cli/
├── packages/
│   ├── agents/
│   ├── schemas/
│   └── utils/
├── runtime/
│   ├── logs/
│   ├── missions/
│   ├── scheduler/
│   └── temp/
├── .github/workflows/
├── .env.example
├── package.json
├── pnpm-workspace.yaml
└── turbo.json
```

## 🏁 Quickstart

1. `pnpm install`
2. Set up `.env` (copy `.env.example`)
3. Start DB/Redis, then:  
   - `pnpm dev` (all apps)  
   - or `pnpm --filter dashboard dev` (just dashboard)
4. Build for prod: `pnpm build`

## 🧬 All agent, app, and doc logic is unified here. See `/docs/` for SOPs, agent glossary, and licensing.

---