/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

document.addEventListener('DOMContentLoaded', () => {
  // Smooth scroll for anchor links
  const ctaButton = document.querySelector('.cta-button');
  if (ctaButton) {
    ctaButton.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = (e.target as HTMLAnchorElement).getAttribute('href');
      if (targetId) {
        document.querySelector(targetId)?.scrollIntoView({
          behavior: 'smooth',
        });
      }
    });
  }
});
